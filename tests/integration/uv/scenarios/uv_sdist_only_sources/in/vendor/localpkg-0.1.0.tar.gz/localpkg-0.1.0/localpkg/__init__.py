__version__ = "0.1.0"


def greet() -> str:
    return "hello from localpkg"
